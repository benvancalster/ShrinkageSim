################################################
################################################
# Scenario 3EPV noiseFALSE 5pred 0corr 0.1prev #
################################################
################################################

#~~~~ LOAD FUNCTIONS ~~~~#
source('Func_datagen_modeling.R')
require(MASS)


#################
# GENERATE DATA #
#################

# SPECIFICATIONS SIMULATION #
#############################

correlation = 0 
EPV = 3
event.rate = 0.1 
nr_pred = 5 # number of predictors 
real.model <- 1
beta0 <- -2.57 # intercept

noise = F
sim.formula <- formula(paste("TO~",paste("x",1:nr_pred,collapse="+",sep="")))

# general settings
nrsim           = 1E3                      # number of simulations
var.standardize = T                        # standardize the simulated variables?
nr.obs.s        = 1E6                      # number of observations in test- and trainingsdata
nr.sim.pred     = 10
n               = (EPV*nr_pred)/event.rate # sample size training data
n.one           = EPV*nr_pred              # events training data
n.zero          = n - n.one                # non-events training data
if((n.one+n.zero)!=n){stop("total n is not equal to n.one+n.zero")}
simulations.corr = F	                       # correl. not controlled, random gen. of values

scenario.nr <- "/scenario 17_"

# SAVE SEEDS SAMPLES
seed.zero     = 100:1099
seed.one      = 20000:20999
seed.pen.l2   = 3E4:3.1E4
seed.gcv.l2   = 3.2E4:3.3E4
seed.gcv.l1   = 3.4E4:3.5E4
seed.gcv.al   = 3.6E4:3.7E4
seed.poly     = 3.8E4:3.9E4
seed.ada      = 4E4:4.1E4
seed.lqa.nng  = 4.2E4:4.3E4
seed.nngccd   = 4.4E4:4.5E4

name.file <- paste(scenario.nr, EPV,"EPV ","noise",noise," ", nr_pred,"pred ",correlation,"corr ", event.rate,"prev",sep="")

# Prepare for liftoff #
#######################

#automatically store results
seq(from=100,to=10000,by=100) -> vector.sim

# prepare to write data
loc.files <- paste("/data/leuven/316/vsc31641",name.file,sep="")
loc.simulation.results <- paste(loc.files,"/simulation results",sep="")
loc.simulation.data <- paste(loc.files,"/simulated data",sep="")
runif(1)
loc.RNG <- paste(loc.files,"/random number generator R",sep="")
loc.workerdata <- paste(loc.files,"/data for workers",sep="")

dir.create(loc.files)
dir.create(loc.simulation.results)
dir.create(loc.simulation.data)
dir.create(loc.RNG)
dir.create(loc.workerdata)
rng.state <- .Random.seed
write.table(rng.state,paste(loc.RNG,"/rng.current.session.txt",sep=""),sep="\t",row.names=F)

# Create test set #
###################

if(simulations.corr==F){
  set.seed(1)
  x1 <- as.matrix(rnorm(nr.obs.s))
  set.seed(2)
  x2 <- as.matrix(rnorm(nr.obs.s))
  set.seed(3)
  x3 <- as.matrix(rnorm(nr.obs.s))
  set.seed(4)
  x4 <- as.matrix(rnorm(nr.obs.s))
  set.seed(5)
  x5 <- as.matrix(rnorm(nr.obs.s))
  set.seed(6)
  x6 <- as.matrix(rnorm(nr.obs.s))
  set.seed(7)
  x7 <- as.matrix(rnorm(nr.obs.s))
  set.seed(8)
  x8 <- as.matrix(rnorm(nr.obs.s))
  set.seed(9)
  x9 <- as.matrix(rnorm(nr.obs.s))
  set.seed(10)
  x10 <- as.matrix(rnorm(nr.obs.s))
  
  if(real.model==1){
    lp0=beta0+0.2*x1+0.2*x2+0.2*x3+0.5*x4+0.8*x5
  }else if(real.model==2){
    lp0=beta0+0.2*x1+0.2*x2+0.2*x3+0.5*x4+0.8*x5+0.2*x6+0.2*x7+0.2*x8+0.5*x9+0.8*x10  
  }

  p0true=exp(lp0)/(1+exp(lp0))
  set.seed(11)
  TO <-rbinom(nr.obs.s,1,p0true)
  
  #create data frame
  testdata <- data.frame(x1=x1, x2=x2, x3=x3, x4=x4, x5=x5, x6=x6, x7=x7,
                         x8=x8, x9=x9, x10=x10,p0true=p0true, TO=TO)
  rm(x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, lp0,p0true,TO)
}else{
  testdata <- correlated.data(use.mvr = T,correlation, nr.sim.pred ,real.model=real.model,seed1=1,seed2=2,numobs = nr.obs.s,
                              beta0=beta0)
}

#if(var.standardize==T){
#  testdata[,1:10] <- scale(testdata[,1:10])
#}

# Create training population #
##############################

#SET SAMPLE SIZE
N=nr.obs.s		#total N training data

if(simulations.corr==F){
  set.seed(12)
  x1 <- as.matrix(rnorm(N))
  set.seed(13)
  x2 <- as.matrix(rnorm(N))
  set.seed(14)
  x3 <- as.matrix(rnorm(N))
  set.seed(15)
  x4 <- as.matrix(rnorm(N))
  set.seed(16)
  x5 <- as.matrix(rnorm(N))
  set.seed(17)
  x6 <- as.matrix(rnorm(N))
  set.seed(18)
  x7 <- as.matrix(rnorm(N))
  set.seed(19)
  x8 <- as.matrix(rnorm(N))
  set.seed(20)
  x9 <- as.matrix(rnorm(N))
  set.seed(21)
  x10 <- as.matrix(rnorm(N))
  
  if(real.model==1){
    lp0=beta0+0.2*x1+0.2*x2+0.2*x3+0.5*x4+0.8*x5
  }else if(real.model==2){
    lp0=beta0+0.2*x1+0.2*x2+0.2*x3+0.5*x4+0.8*x5+0.2*x6+0.2*x7+0.2*x8+0.5*x9+0.8*x10  
  }
 
  p0true=exp(lp0)/(1+exp(lp0))
  set.seed(22)
  TO <-rbinom(N,1,p0true)
  trainingset0 <- data.frame(x1=x1, x2=x2, x3=x3, x4=x4, x5=x5, x6=x6, x7=x7, x8=x8, x9=x9, x10=x10,p0true=p0true, TO=TO)
  rm(x1, x2, x3, x4, x5,x6,x7,x8,x9,x10,lp0,p0true,TO)
}else{
  trainingset0 <- correlated.data(use.mvr = T,correlation, nr.sim.pred ,seed1=4,seed2 = 5,real.model=real.model,
                                  numobs=nr.obs.s,beta0=beta0)
}
#if(var.standardize==T){
#  trainingset0[,1:10] <- scale(trainingset0[,1:10])
#}

#$$$ SAVE TEST- AND TRAININGSDATA $$$#
write.table(testdata,paste(loc.simulation.data,"/testdata.txt",sep=""),row.names=F,sep="\t")
write.table(trainingset0,paste(loc.simulation.data,"/trainingsdata.txt",sep=""),row.names=F,sep="\t")

# subset events and non-events
zerotr <- subset(trainingset0,TO==0)
onetr <- subset(trainingset0,TO==1)

i <- 1

# CREATE TRAINING DATASETS #
############################

for (i in i:nrsim){

  set.seed(seed.zero[i])
  samplezero <- sample(1:nrow(zerotr),size=n.zero)
  training_0 <- zerotr[samplezero,]
  set.seed(seed.one[i])
  sampleone <- sample(1:nrow(onetr),size=n.one)
  training_1 <- onetr[sampleone,]
  
  trainingset <- rbind(training_0,training_1)
  if(var.standardize==T){
    trainingset[,1:10] <- scale(trainingset[,1:10])
  }
  write.table(trainingset,paste(loc.workerdata,scenario.nr,"_",i,".txt",sep=""),row.names = F)
  
}


#####################
# APPLY THE METHODS #
#####################


# Done on HPC (high performance computing) cluster
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
#   WORKER FUNCTION ON HPC CLUSTER   #
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#

args <- commandArgs(TRUE)
i <- as.integer(args[1])
scenario <- 17

# Possible_scenarios.txt contains an overview of all 60 simulation scenarios
prep.names <- read.delim("/user/leuven/316/vsc31641/R_scripts/Possible_scenarios.txt")
prep.names <- prep.names[which(prep.names$Scenario==scenario),]

path.files <- with(prep.names,paste("scenario ",Scenario,"_",EPV,"EPV noise",Noise," ",Predictors,"pred ",Correlation,
                                    "corr ",Event.rate,"prev",sep=""))
sampled.data <- read.table(paste("/data/leuven/316/vsc31641/",path.files,"/data for workers/scenario ",scenario,"__",
                                 i,".txt",sep=""),header=T)
testdata <- read.table(paste("/data/leuven/316/vsc31641/",path.files,"/simulated data/testdata.txt",sep=""),header=T)

nr_pred <- prep.names$Predictors
noise <- prep.names$Noise
var.standardize = T

#~~ FIX FORMULA ~~#
nr_pred2 = nr_pred
if(nr_pred2 == 5 & noise)
  nr_pred2 = 10

#~~ PATH LIBRARY ON HPC ~~#
.libPaths("/user/leuven/316/vsc31641/Rpackages/")
# nngccd is a self-written package that has to be installed first
LibraryM(c("rms", "ROCR", "boot", "Hmisc", "glmnet", "logistf",
           "MASS", "nngccd"))

# SPECIFICATIONS SIMULATION #
#############################

# diff.simul
real.model = 
  if(nr_pred == 5) {
    1
  } else if(nr_pred ==10) {
    2
  }

sim.formula = 
  if(!noise){
    formula(paste0("TO ~ ", paste("x", 1:nr_pred, collapse = "+")))
  }else{
    formula(paste0("TO ~ ",paste("x", 1:10, collapse = "+")))
  }

# general settings
opt.and.prof.l1               = 0

# lambda values
lambda.seq.1                  = c(10^seq(1.8065, -2, length = 200), 0)
lambda.seq.2                  = c(exp(seq(log(64), log(1e-4), length.out = 250)), 0)

#-----------------------------------------------------------------#
#                       START SIMULATIONS                         #
#-----------------------------------------------------------------#

# SAVE SEEDS SAMPLES
seed.zero     = 100:1099
seed.one      = 20000:20999
seed.pen.l2   = 3E4:3.1E4
seed.gcv.l2   = 3.2E4:3.3E4
seed.gcv.l1   = 3.4E4:3.5E4
seed.gcv.al   = 3.6E4:3.7E4
seed.poly     = 3.8E4:3.9E4
seed.ada      = 4E4:4.1E4
seed.lqa.nng  = 4.2E4:4.3E4
seed.nngccd   = 4.4E4:4.5E4

#--------------------#
#CREATE TRAINING DATA#
#--------------------#
trainingset = sampled.data

if(var.standardize){
  trainingset[,1:10] = scale(trainingset[,1:10])
}

separation = F

y = trainingset$TO
x = model.matrix(sim.formula, data = trainingset)
Y = testdata$TO
X = model.matrix(sim.formula, data = testdata)

#### 1. Standard Logistic model ####

ST = tryCatch(glm(sim.formula, family = binomial, data = trainingset),
              error = function(e) T, warning=function(w) T)

if(!is.logical(ST)){
  
  # Coefficients ST
  STcoeff2 = coef(ST)
  predST   = fitted(ST)
  
  # AUC
  cd_ST = AUC(predST, y)
  
  #~~~~TEST SET~~~~#
  
  # AUC & calibration slope
  P = Ilogit(X %*% as.vector(STcoeff2))
  ST_c_cs2 = GetPerf(P, Y)
  
  # COMBINE
  STmodel = c(STcoeff2, cd_ST, ST_c_cs2, 0)
} else {
  STmodel = c(rep(NA, nr_pred2 + 1), rep(NA, 5), 0)
}

names(STmodel) = c("Intercept", paste0("x",1:nr_pred2), "cd.ST", "ct.ST", "ci.ST", "cs.ST",   
                   "rmse.ST","mle.separation")

#### 2. Likelihood based uniform shrinkage ####

if(!is.logical(ST)){
  
  #~~~~TRAINING SET~~~~#
  
  # Shrinkage factor
  ST  = glm(sim.formula, family = binomial, data = trainingset)
  ST0 = glm(TO ~ 1, family = binomial, data = trainingset)
  
  chi2model = ST$null.deviance - ST$deviance
  
  # check
  if(!approx.eq(chi2model,lrtest(ST,ST0)$stats[1]))
    stop("Error in LU shrinkage")
  
  shrinkfactor = ((chi2model - nr_pred2) / chi2model)
  BetaLU       = ST$coefficients
  BetaLU	     = c(BetaLU[1], shrinkfactor * BetaLU[-1])
  
  # adjust intercept so mean pred prob = incidence
  BetaLU = AdjBeta0(BetaLU, x, y)
  
  #~~~~TEST SET~~~~#
  P = Ilogit(X %*% BetaLU)
  LU_c_cs = GetPerf(P, Y)
  LUmodel = c(BetaLU, LU_c_cs, shrinkfactor)
} else {
  LUmodel = c(rep(NA, nr_pred2 + 1), rep(NA, 5))
}
names(LUmodel) = c("Intercept.ST", paste0("x",1:nr_pred2, ".ST"), "ct.ST", "ci.ST", "cs.ST", 
                   "rmse.ST", "shrinkage.factor")
names(LUmodel) = gsub(".ST", ".LU", names(LUmodel), fixed = T)
results = c(STmodel, LUmodel)

#### 3. Bootstrap-based uniform shrinkage ####

if(!is.logical(ST)){
  nr.warnings.bt = 0
  
  #~~~~TRAINING SET~~~~#
  #function for BT
  zero = trainingset[which(trainingset$TO == 0), ]
  one  = trainingset[which(trainingset$TO == 1), ]
  
  BTcs = sapply(1:200, function(h) {
    repeat{	
      BTzero = zero[sample(1:nrow(zero), replace = T), ]
      BTone  = one[sample(1:nrow(one), replace = T), ]
      BTdf   = rbind.data.frame(BTzero, BTone)
      STbt   = tryCatch(glm(sim.formula, family = binomial, data = BTdf),
                        warning = function(w) w)
      if(inherits(STbt, c("simpleWarning","warning")))
        nr.warnings.bt <<- nr.warnings.bt + 1
      else
        break
    }
    LP = x %*% coef(STbt)
    CalSlop = lrm.fit(LP, y)$coefficients[2]
    return(CalSlop)
  }, simplify = T)
  
  # Mean cs
  AvgCS  = mean(BTcs)
  BetaBT = c(STcoeff2[1], AvgCS * STcoeff2[-1])
  
  # Adjust intercept
  BetaBT = AdjBeta0(BetaBT, x, y)
  
  # Performance test set
  P = Ilogit(X %*% BetaBT)
  BU_c_cs = GetPerf(P, Y)
  BUmodel = c(BetaBT, BU_c_cs, AvgCS, nr.warnings.bt)
} else {
  BUmodel = c(rep(NA, nr_pred2 + 1), rep(NA, 6))
}

names(BUmodel) = c("Intercept.ST", paste0("x",1:nr_pred2, ".ST"), "ct.ST", "ci.ST", "cs.ST", 
                   "rmse.ST", "shrinkage.factor.BU", "BT.errors")
names(BUmodel) = gsub(".ST", ".BU", names(BUmodel), fixed = T)
results = c(results, BUmodel)

#### 4. Ridge regression - GLMNET ####

set.seed(seed.gcv.l2[i])
Fitg_CV = cv.glmnet(x[, -1], y, family = "binomial", alpha = 0, nfolds = 10, lambda =   
                      rev(lambda.seq.2), standardize = !var.standardize)
LambdaMinGnet = Fitg_CV$lambda.min
BetaGnetL2.lmin = as.vector(predict.cv.glmnet(Fitg_CV, s = "lambda.min", type =   
                                                "coefficients"))

plmin = predict.cv.glmnet(Fitg_CV, x[, -1], s = "lambda.min", type = "response")
AUClmin = AUC(plmin, y)
Plmin = Ilogit(X %*% BetaGnetL2.lmin)
L2g_c_cs_lmin = GetPerf(Plmin, Y)
GnetL2lmin = c(BetaGnetL2.lmin, AUClmin, LambdaMinGnet, L2g_c_cs_lmin)
names(GnetL2lmin) = c("Intercept.ST", paste0("x",1:nr_pred2, ".ST"), "cd.ST", "lambda.ST",   
                      "ct.ST","ci.ST","cs.ST","rmse.ST")
names(GnetL2lmin) = gsub(".ST", ".L2g.lambda.min", names(GnetL2lmin), fixed = T)
results = c(results, GnetL2lmin)

#### 5. Lasso - GLMNET ####

set.seed(seed.gcv.l1[i])
Fitg_CV = cv.glmnet(x[, -1], y, family = "binomial", alpha = 1, nfolds = 10, lambda = 
                      rev(lambda.seq.2), standardize = !var.standardize)
LambdaMinGnet = Fitg_CV$lambda.min
BetaGnetL1.lmin = as.vector(predict.cv.glmnet(Fitg_CV, s = "lambda.min", type = 
                                                "coefficients"))

plmin = predict.cv.glmnet(Fitg_CV, x[, -1], s = "lambda.min", type = "response")
AUClmin = AUC(plmin, y)
Plmin = Ilogit(X %*% BetaGnetL1.lmin)
L1g_c_cs_lmin = GetPerf(Plmin, Y)
GnetL1lmin = c(BetaGnetL1.lmin, AUClmin, LambdaMinGnet, L1g_c_cs_lmin)
names(GnetL1lmin) = c("Intercept.ST", paste0("x",1:nr_pred2, ".ST"), "cd.ST", "lambda.ST", 
                      "ct.ST","ci.ST","cs.ST","rmse.ST")
names(GnetL1lmin) = gsub(".ST", ".L1g.lambda.min", names(GnetL1lmin), fixed = T)
results = c(results, GnetL1lmin, "L1g.lambda.min.allzerocoef" =   
              AllZeroCoef(BetaGnetL1.lmin))

#### 6. Adaptive Lasso - GLMNET ####

MLEcoef   = coef(glm(sim.formula, data = trainingset, family = binomial)) 
WeightsAL = 1 / abs(MLEcoef[-1])
set.seed(seed.gcv.al[i])
Fitg_CV = cv.glmnet(x[, -1], y, family = "binomial", alpha = 1, nfolds = 10, lambda = 
                      rev(lambda.seq.2), standardize = !var.standardize, penalty.factor = WeightsAL)
LambdaMinGnet = Fitg_CV$lambda.min
BetaGnetAL    = as.vector(predict.cv.glmnet(Fitg_CV, s = "lambda.min", type = 
                                              "coefficients"))

plmin = predict.cv.glmnet(Fitg_CV, x[, -1], s = "lambda.min", type = "response")
AUClmin = AUC(plmin, y)
Plmin = Ilogit(X %*% BetaGnetAL)
AL_c_cs_lmin = GetPerf(Plmin, Y)
GnetALlmin = c(BetaGnetAL, AUClmin, LambdaMinGnet, AL_c_cs_lmin)
names(GnetALlmin) = c("Intercept.ST", paste0("x",1:nr_pred2, ".ST"), "cd.ST", "lambda.ST", 
                      "ct.ST","ci.ST","cs.ST","rmse.ST")
names(GnetALlmin) = gsub(".ST", ".AL", names(GnetALlmin), fixed = T)
results = c(results, GnetALlmin, "AL.allzerocoef" = AllZeroCoef(BetaGnetAL))

#### 7. Non-negative Garrote ####

set.seed(seed.nngccd[i])
ResGCV       = cv.nng.ccd(x[, -1], y, lambda.seq.2, 10, standardize.cv = !var.standardize)
LambdaNNGCCD = ResGCV$min.lam$lambda.min
ResLambda    = nng.ccd(x[, -1], y, LambdaNNGCCD, F)
BetaNNG      = as.vector(ResLambda$results.nng)
pNNG         = Ilogit(x %*% BetaNNG)
AUCNNG       = AUC(pNNG, y)

PNNG      = Ilogit(X %*% BetaNNG)
NNG_c_cs  = GetPerf(PNNG, Y)
NNGCCDRes = c(BetaNNG, AUCNNG, LambdaNNGCCD, NNG_c_cs)
names(NNGCCDRes) = c("Intercept.ST", paste0("x",1:nr_pred2, ".ST"), "cd.ST", "lambda.ST", 
                     "ct.ST","ci.ST","cs.ST","rmse.ST")
names(NNGCCDRes) = gsub(".ST", ".nng", names(NNGCCDRes), fixed = T)
results = c(results, NNGCCDRes, "nng.allzerocoef" = AllZeroCoef(BetaNNG))

#### 8. Firth ####

Firth     = logistf(sim.formula, data = trainingset)
BetaFirth = coef(Firth) 
BetaFirth = AdjBeta0(BetaFirth, x, y)

pFirth   = Ilogit(x %*% BetaFirth)
AUCFirth = AUC(pFirth, y)

PFirth     = Ilogit(X %*% BetaFirth)
Firth_c_cs = GetPerf(PFirth, Y)
FirthRes   = c(BetaFirth, AUCFirth, Firth_c_cs)
names(FirthRes) = c("Intercept.ST", paste0("x",1:nr_pred2, ".ST"), "cd.ST", 
                    "ct.ST","ci.ST","cs.ST","rmse.ST")
names(FirthRes) = gsub(".ST", ".F", names(FirthRes), fixed = T)
results = c(results, FirthRes)

#### 9. Pentrace (PML) ####

if(results["mle.separation"] == 0) {
  Plrm      = lrm(sim.formula, data = trainingset, x = T, y = T)
  ResPen    = pentrace(Plrm, lambda.seq.1)
  Penlrm    = update(Plrm, penalty = ResPen$penalty)
  LambdaPen = ResPen$penalty
  BetaPent  = Penlrm$coefficients 
  ppen      = Ilogit(x %*% BetaPent)
  AUCpent   = AUC(ppen, y)
  
  PPent     = Ilogit(X %*% BetaPent)
  Pent_c_cs = GetPerf(PPent, Y) 
  PentRes   = c(BetaPent, AUCpent, Pent_c_cs)
} else {
  PentRes   = c(rep(NA, nr_pred2 + 1), rep(NA, 5))
}
names(PentRes) = c("Intercept.ST", paste0("x",1:nr_pred2, ".ST"), "cd.ST", 
                   "ct.ST","ci.ST","cs.ST","rmse.ST")
names(PentRes) = gsub(".ST", ".pent", names(PentRes), fixed = T)
results = c(results, PentRes)

# Combine and save results
results <- as.data.frame(t(results))

write.table(results,paste("Simulation results",scenario,"_",i,".txt",sep=""),sep="\t",row.names=F)

