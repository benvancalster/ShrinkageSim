### Information on R code to generate data, and apply models
The file Datagen_modeling.R contains the code to generate data and apply models for one scenario. Modeling for all simulation scenarios was done on a High Performance Computing (HPC) cluster.
This dataset uses functions in Func_datagen_modeling.R, the overview of scenarios in Possible_scenarios.txt, and a self-written R package for the non-negative Garrote (nngccd_0.1.2.zip).
All of this was done with the help of Bavo De Cock (github.com/BavoDC).