#%%%%%%%%%%%%%%%%%%%%%#
# Functions shrinkage #
#%%%%%%%%%%%%%%%%%%%%%#

#### 0. Simulate correlated data ####
correlated.data <- function(use.mvr=T,correlation,nr.sim.pred,seed1=1,seed2=2,real.model=1,numobs = 1E5,beta0){
  if(use.mvr==T){
    R = diag(1,nr.sim.pred,nr.sim.pred)
    R[lower.tri(R)] <- correlation;R[upper.tri(R)] <- correlation
    
    raw <- as.matrix(mvrnorm(numobs,rep(0,nr.sim.pred),R))
    print(round(cor(raw),3))
  }else{
    R = diag(1,nr.sim.pred,nr.sim.pred)
    R[lower.tri(R)] <- correlation;R[upper.tri(R)] <- correlation
    
    U = t(chol(R))
    nvars = dim(U)[1]
    
    set.seed(seed1)
    random.normal = matrix(rnorm(nvars*numobs,0,1), nrow=nvars, ncol=numobs);
    X = U %*% random.normal
    newX = t(X)
    raw = as.matrix(newX)
  }
  if(real.model==1){
    lp0 <- cbind(1,raw[,1:5])%*%c(beta0,rep(0.2,3),0.5,0.8)
  }else if(real.model==2){
    lp0 <- cbind(1,raw)%*%c(beta0,rep(0.2,3),0.5,0.8,rep(0.2,3),0.5,0.8) 
  }else if(real.model==3){
    lp0 <- cbind(1,raw[,1:5])%*%c(beta0,rep(0.2,3),1.5,-0.8)
  }
  p0true=exp(lp0)/(1+exp(lp0))
  set.seed(seed2)
  TO <-rbinom(numobs,1,p0true)
  data.corr <- cbind.data.frame(raw,lp0,p0true,TO)
  names(data.corr) <- c(paste("x",1:nr.sim.pred,sep=""),"lp0","p0true","TO")
  return(data.corr)
}

#### 1. Useful functions ####
V           = binomial()$variance
Logit       = binomial()$linkfun
Ilogit      = binomial()$linkinv
approx.eq   = function(x, y, max.diff = 1e-2) abs(x - y) < max.diff
AllZeroCoef = function(x) if(all(x[-1] == 0)) 1 else 0 


#### 2. Performance measures ####

#### 2.1 AUC ####
AUC <- function(p, y) { 
  if(min(p) < 0 | max(p) > 1)
    stop("probabilities greater than 1 or smaller than 0")
  else if(!all(y %in% c(0, 1)))
    stop("the outcome does not contain the values 0 and 1")
  
  c("AUC" = as.numeric(performance(prediction(p, y), "auc")@y.values))
  }

#### 2.2 Calibration ####
Calibr <- function(p, y){
  if(min(p) < 0 | max(p) > 1)
    stop("probabilities greater than 1 or smaller than 0")
  else if(!all(y %in% c(0, 1)))
    stop("the outcome does not contain the values 0 and 1")
  
  if(any(p %in% c(0, 1)))
    p = sapply(p, function(x) if(x == 0) 1e-6 else if(x == 1) 1 - 1e-6 else x)
  
  LP  = Logit(p)
  Fit = lrm.fit(LP, y)
  
  if(Fit$fail) {
    Fit2 = glm(y ~ LP, family = binomial)
    if(!Fit2$converged) {
      CalIFit = glm(y ~ 1, family = binomial, offset = LP)
      if(CalIFit$converged) {
        CalInter = unname(coef(CalIFit)[1])
        CalSlope = NA
      } else {
        CalInter = CalSlope = NA
      }
    } else {
      CalSlope = unname(Fit2$coefficients[2])
      CalInter = unname(glm(y ~ 1, family = binomial, offset = LP)$coefficients[1])
    }
  } else {
    CalSlope = unname(Fit$coefficients[2])
    CalInter = unname(lrm.fit(y = y, offset = LP)$coefficients[1])
    if(is.null(CalInter)) {
      CalIFit = glm(y ~ 1, family = binomial, offset = LP)
      if(CalIFit$converged)
        CalInter = unname(coef(CalIFit)[1])
      else
        CalInter = CalSlope = NA
    }
  }
  return(c(CalInter = CalInter, CalSlope = CalSlope))
}

#### 2.3 RMSE predictions ####
RMSE <- function(p, y) sqrt(crossprod(y - p) / length(p))

#### 2.4 Combine functions ####
GetPerf <- function(p, y) {
  if(length(unique(p)) != 1)
    c(AUC(p, y), Calibr(p, y), RMSE = RMSE(p, y))
  else
    c(AUC = 0.5, CalInter = NA, CalSlope = NA, RMSE = RMSE(p, y))
}

#### 2.5 Prevent simulations from stopping ####
PreventTheEnd <- function(p, y) {
  tryCatch(GetPerf(p, y),
           error = function(e) c(0.5, rep(NA, 2)),
           warning = function(w) c(0.5, rep(NA, 2)))
}

#### 2.6 Catch warnings ####
factory <- function(fun){
  warn <- err <- NULL
  res <- withCallingHandlers(
    tryCatch(fun(...), error=function(e) {
      err <<- conditionMessage(e)
      NULL
    }), warning=function(w) {
      warn <<- append(warn, conditionMessage(w))
      invokeRestart("muffleWarning")
    })
  list(res, warn=warn, err=err)
}

#### 2.7 Extract coefficients glmnet object ####
CoefGlmnet <- function(x) t(as.matrix(x))


#### 2.8 Adjust intercept ####
AdjBeta0 <- function(Beta, x, y) {
  LP      = x %*% Beta
  UpdInt  = lrm.fit(offset = LP, y = y)
  Beta[1] = Beta[1] + UpdInt$coefficients[1]
  return(Beta)
}














